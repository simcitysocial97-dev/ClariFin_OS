import reflex as rx
from ..state import FinanceState


def metric_card(
    title: str, 
    value: rx.Var, 
    subtitle: str = "", 
    icon_name: str = "wallet",
    subtitle_color: str = "gray",
) -> rx.Component:
    """Metric card using Radix props for reliable styling."""
    return rx.card(
        rx.flex(
            rx.flex(
                rx.icon(icon_name, size=18, color="var(--accent-9)"),
                rx.text(title, size="1", weight="medium", color="gray"),
                align="center",
                gap="2",
            ),
            rx.text(value, size="6", weight="bold", trim="both"),
            rx.cond(
                subtitle != "",
                rx.text(subtitle, size="1", color=subtitle_color),
                rx.fragment(),
            ),
            direction="column",
            gap="1",
        ),
        size="3",
    )


def chart_section(title: str, chart: rx.Component, height: int = 280) -> rx.Component:
    """Chart wrapper using Radix props."""
    return rx.card(
        rx.flex(
            rx.text(title, size="3", weight="bold"),
            rx.separator(size="4"),
            rx.box(
                rx.recharts.responsive_container(
                    chart,
                    width="100%",
                    height=height,
                ),
                width="100%",
                min_height=f"{height}px",
            ),
            direction="column",
            gap="3",
        ),
        size="3",
    )


def monthly_bar_chart() -> rx.Component:
    """Monthly spending bar chart with Radix color tokens."""
    return rx.recharts.bar_chart(
        rx.recharts.cartesian_grid(
            stroke_dasharray="3 3",
            stroke="var(--gray-4)",
            vertical=False,
        ),
        rx.recharts.x_axis(
            data_key="month",
            tick={"fill": "var(--gray-9)", "fontSize": 11},
            axis_line=False,
            tick_line=False,
        ),
        rx.recharts.y_axis(
            tick={"fill": "var(--gray-9)", "fontSize": 11},
            axis_line=False,
            tick_line=False,
        ),
        rx.recharts.tooltip(
            content_style={
                "backgroundColor": "var(--gray-2)",
                "border": "1px solid var(--gray-6)",
                "borderRadius": "8px",
                "color": "var(--gray-12)",
                "fontSize": "12px",
            },
        ),
        rx.recharts.bar(
            data_key="amount",
            fill="var(--accent-9)",
            radius=[4, 4, 0, 0],
        ),
        data=FinanceState.monthly_chart_data,
    )


def category_bar_chart() -> rx.Component:
    """Category horizontal bar chart with Radix color tokens."""
    return rx.recharts.bar_chart(
        rx.recharts.cartesian_grid(
            stroke_dasharray="3 3",
            stroke="var(--gray-4)",
            horizontal=True,
            vertical=False,
        ),
        rx.recharts.y_axis(
            data_key="name",
            type_="category",
            tick={"fill": "var(--gray-9)", "fontSize": 11},
            width=120,
            axis_line=False,
            tick_line=False,
        ),
        rx.recharts.x_axis(
            type_="number",
            tick={"fill": "var(--gray-9)", "fontSize": 11},
            axis_line=False,
            tick_line=False,
        ),
        rx.recharts.tooltip(
            content_style={
                "backgroundColor": "var(--gray-2)",
                "border": "1px solid var(--gray-6)",
                "borderRadius": "8px",
                "color": "var(--gray-12)",
                "fontSize": "12px",
            },
        ),
        rx.recharts.bar(
            data_key="value",
            fill="var(--accent-9)",
            radius=[0, 4, 4, 0],
        ),
        data=FinanceState.category_chart_data,
        layout="vertical",
    )


def bank_bar_chart() -> rx.Component:
    """Bank-wise horizontal bar chart with Radix color tokens."""
    return rx.recharts.bar_chart(
        rx.recharts.cartesian_grid(
            stroke_dasharray="3 3",
            stroke="var(--gray-4)",
            horizontal=False,
        ),
        rx.recharts.x_axis(
            type_="number",
            tick={"fill": "var(--gray-9)", "fontSize": 11},
            axis_line=False,
            tick_line=False,
        ),
        rx.recharts.y_axis(
            data_key="bank",
            type_="category",
            tick={"fill": "var(--gray-9)", "fontSize": 11},
            width=100,
            axis_line=False,
            tick_line=False,
        ),
        rx.recharts.tooltip(
            content_style={
                "backgroundColor": "var(--gray-2)",
                "border": "1px solid var(--gray-6)",
                "borderRadius": "8px",
                "color": "var(--gray-12)",
            },
        ),
        rx.recharts.bar(
            data_key="amount",
            fill="var(--accent-9)",
            radius=[0, 4, 4, 0],
        ),
        data=FinanceState.bank_chart_data,
        layout="vertical",
    )


def recent_transactions_table() -> rx.Component:
    """Recent transactions table using Radix table props."""
    return rx.cond(
        FinanceState.recent_transactions,
        rx.table.root(
            rx.table.header(
                rx.table.row(
                    rx.table.column_header_cell("Date", width="100px"),
                    rx.table.column_header_cell("Description"),
                    rx.table.column_header_cell("Amount", width="120px", align="right"),
                    rx.table.column_header_cell("Type", width="80px"),
                ),
            ),
            rx.table.body(
                rx.foreach(
                    FinanceState.recent_transactions,
                    lambda txn: rx.table.row(
                        rx.table.cell(txn["date_display"]),
                        rx.table.cell(
                            rx.text(txn["description_display"], size="2"),
                        ),
                        rx.table.cell(
                            rx.text(
                                txn["amount_display"],
                                size="2",
                                weight=rx.cond(txn["is_large"], "bold", "medium"),
                                text_align="right",
                                font="mono",
                                color=rx.cond(txn["is_large"], "var(--amber-9)", "var(--gray-12)"),
                            ),
                            align="right",
                        ),
                        rx.table.cell(
                            rx.badge(
                                txn["type"],
                                color_scheme=rx.cond(
                                    txn["type"] == "credit",
                                    "green",
                                    "gray",
                                ),
                                variant="soft",
                                size="1",
                            ),
                        ),
                    ),
                ),
            ),
            size="2",
            variant="surface",
        ),
        rx.flex(
            rx.icon("inbox", size=32, color="var(--gray-8)"),
            rx.text("No transactions yet", size="2", color="var(--gray-9)"),
            direction="column",
            align="center",
            gap="2",
            padding="6",
        ),
    )


def error_banner() -> rx.Component:
    """Error banner using Radix callout."""
    return rx.cond(
        FinanceState.error_message != "",
        rx.callout.root(
            rx.callout.icon(rx.icon("triangle-alert", size=16)),
            rx.callout.text(FinanceState.error_message),
            color="red",
            variant="soft",
        ),
        rx.fragment(),
    )


def overview_page() -> rx.Component:
    """Overview page using Radix component props."""
    return rx.box(
        # Header
        rx.heading("Overview", size="7", weight="bold", mb="6"),
        
        # Error banner
        error_banner(),
        
        # Exclude Transfers Toggle (between header and metrics)
        rx.flex(
            rx.text("Spending Analysis", size="1", color="gray"),
            rx.flex(
                rx.text("Exclude Transfers", size="1", color="gray"),
                rx.switch(
                    checked=FinanceState.exclude_transfers,
                    on_change=FinanceState.toggle_exclude_transfers,
                    size="1",
                ),
                align="center",
                gap="2",
            ),
            justify="between",
            align="center",
            width="100%",
            mb="4",
        ),
        
        # Metrics
        rx.grid(
            metric_card("Total Spend", FinanceState.total_spend,
                       FinanceState.total_months_display, "wallet"),
            metric_card("This Month", FinanceState.this_month_spend,
                       FinanceState.above_avg_display, "calendar",
                       subtitle_color=FinanceState.above_avg_color),
            metric_card("Last Month", FinanceState.last_month_spend,
                       FinanceState.month_change, "calendar-check"),
            metric_card("Transactions", FinanceState.transaction_count_display,
                       FinanceState.avg_txn_display, "receipt"),
            columns=rx.breakpoints(initial="1", sm="2", lg="4"),
            gap="4",
            mb="6",
        ),
        
        # Charts row
        rx.grid(
            chart_section("Monthly Spending", monthly_bar_chart()),
            chart_section("Category Split", category_bar_chart()),
            columns=rx.breakpoints(initial="1", lg="2"),
            gap="4",
            mb="6",
        ),
        
        # Bottom row
        rx.grid(
            chart_section("Bank-wise Spend", bank_bar_chart(), height=220),
            rx.card(
                rx.flex(
                    rx.text("Recent Transactions", size="3", weight="bold"),
                    rx.separator(size="4"),
                    recent_transactions_table(),
                    direction="column",
                    gap="3",
                ),
                size="3",
            ),
            columns=rx.breakpoints(initial="1", lg="2"),
            gap="4",
        ),
        
        padding="6",
    )