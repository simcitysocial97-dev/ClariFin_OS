import reflex as rx
from ..state import FinanceState


NAV_ITEMS = [
    ("/", "layout-dashboard", "Overview"),
    ("/transactions", "receipt", "Transactions"),
    ("/categories", "pie-chart", "Categories"),
    ("/analytics", "trending-up", "Analytics"),
    ("/cards", "credit-card", "Cards"),
    ("/upload", "upload", "Upload"),
]


def nav_item(href: str, icon: str, label: str) -> rx.Component:
    """Navigation item with active state highlighting."""
    is_active = rx.State.router.page.path == href
    return rx.link(
        rx.flex(
            rx.icon(icon, size=16),
            rx.text(label, size="2", weight="medium"),
            align="center",
            gap="3",
            padding="2",
            border_radius="var(--radius-2)",
            width="100%",
            bg=rx.cond(is_active, "var(--accent-3)", "transparent"),
            color=rx.cond(is_active, "var(--accent-11)", "var(--gray-11)"),
            _hover={"bg": rx.cond(is_active, "var(--accent-3)", "var(--gray-3)")},
        ),
        href=href,
        underline="none",
        width="100%",
    )


def sidebar() -> rx.Component:
    """Sidebar with logo, navigation, and bottom controls."""
    return rx.box(
        rx.flex(
            # Top section: Logo
            rx.flex(
                rx.flex(
                    rx.icon("indian-rupee", size=20, color="var(--accent-9)"),
                    rx.text("FinTrack", size="5", weight="bold"),
                    align="center",
                    gap="2",
                ),
                rx.text("Personal Finance", size="1", color="var(--gray-9)"),
                direction="column",
                gap="1",
            ),
            rx.separator(size="2", margin_top="4", margin_bottom="4"),
            
            # Middle section: Navigation
            rx.flex(
                *[nav_item(href, icon, label) for href, icon, label in NAV_ITEMS],
                direction="column",
                gap="1",
                width="100%",
            ),
            
            # Spacer to push bottom section down
            rx.spacer(),
            
            # Bottom section
            rx.separator(size="2", margin_top="4", margin_bottom="4"),
            rx.flex(
                rx.color_mode.button(size="1"),
                rx.button(
                    rx.icon("refresh-cw", size=14),
                    "Refresh",
                    variant="ghost",
                    size="1",
                    on_click=FinanceState.load_all_data,
                ),
                gap="2",
                width="100%",
            ),
            rx.text(
                FinanceState.transaction_count_display + " transactions",
                size="1",
                color="var(--gray-9)",
                margin_top="2",
            ),
            
            direction="column",
            height="100%",
            padding="4",
        ),
        bg="var(--gray-1)",
        border_right="1px solid var(--gray-4)",
        width="240px",
        min_height="100vh",
    )