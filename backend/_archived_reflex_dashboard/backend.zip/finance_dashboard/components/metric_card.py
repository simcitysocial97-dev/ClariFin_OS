import reflex as rx
from ..styles import METRIC_CARD_STYLE, LABEL_STYLE, AMOUNT_STYLE


def metric_card(
    title: str,
    value,
    subtitle: str = "",
    icon: str = "wallet",
    trend: str = "",
    accent_color: str = "#6366F1",
    icon_bg: str = "bg-indigo-500/10",
    icon_color: str = "text-indigo-400",
) -> rx.Component:
    return rx.box(
        rx.vstack(
            # Top row: icon + label
            rx.hstack(
                rx.box(
                    rx.icon(icon, size=16, class_name=icon_color),
                    class_name=f"w-8 h-8 {icon_bg} rounded-lg flex items-center justify-center",
                ),
                rx.text(title, class_name=LABEL_STYLE),
                justify="between",
                width="100%",
                align="center",
            ),
            # Value
            rx.text(value, class_name=AMOUNT_STYLE),
            # Subtitle (always rendered, may be empty string)
            rx.text(subtitle, class_name="text-xs text-zinc-500"),
            spacing="2",
            align="start",
            width="100%",
        ),
        class_name=METRIC_CARD_STYLE,
        style={"border_left": f"3px solid {accent_color}"},
    )
